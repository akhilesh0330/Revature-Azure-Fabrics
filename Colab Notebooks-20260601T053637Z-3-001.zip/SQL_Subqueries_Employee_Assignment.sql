create database subqueries;
use subqueries;

create table Employees (
    EmployeeID INT PRIMARY KEY,
    EmployeeName VARCHAR(100),
    Department VARCHAR(50),
    Salary DECIMAL(10,2),
    ManagerID INT,
    HireDate DATE
)
insert into Employees(EmployeeID, EmployeeName, Department, Salary, ManagerID, HireDate)
VALUES 
(101, 'John', 'Sales', 50000, 201, '2021-01-10'),
(102, 'Mary', 'Sales', 65000, 201, '2020-03-15'),
(103, 'David', 'HR', 55000, 202, '2022-05-20'),
(104, 'Sophia', 'HR', 70000, 202, '2019-07-18'),
(105, 'James', 'IT', 80000, 203, '2018-11-01'),
(106, 'Emma', 'IT', 75000, 203, '2021-09-25'),
(107, 'Michael', 'Finance', 90000, 204, '2017-06-12'),
(108, 'Olivia', 'Finance', 60000, 204, '2023-02-01');

---Q1
select salary
from Employees
where salary>(select avg(salary) from Employees);
--Q2
select EmployeeName,salary
from Employees
where salary=(select max(salary) from Employees)
Q3
select EmployeeName,salary
from Employees 
where salary=(select max(salary) 
	from Employees
	where salary<(select max(salary) from Employees));
  Q4  
select salary
from Employees
where salary<(select max(salary) from Employees);
Q5
select EmployeeName, Department,salary
from Employees
where Department=(select Department 
	from Employees
	where salary=(select max(salary) from Employees));
Q6
select salary
from Employees
where salary>70000;
Q7
select EmployeeName, Department,salary
from Employees e1
where salary>(select avg(salary) Department 
	from Employees e2
	where e1.Department=e2.Department);
Q8
select EmployeeName, Department,salary
from Employees
where salary>all (select max(salary)
	from Employees
	where Department='HR');
Q9
select EmployeeName, Department,salary
from Employees
where salary in (select (salary)
	from Employees
	where Department='Sales');
    
Q10
select EmployeeName, HireDate,salary
from Employees
where HireDate> (select (HireDate)
	from Employees
	where salary=(select min(salary) from Employees));
Q11
select Department
from Employees
group by Department
order by avg(salary) desc
limit 1;
Q12
select Department,min(salary) as ag
from Employees
group by Department ;
Q13
select ManagerID
from Employees
where salary>75000;
Q14
SELECT e.EmployeeName, e.salary AS EmployeeSalary, e.ManagerID
FROM Employees e
WHERE e.salary > (
    SELECT m.salary 
    FROM Employees m 
    WHERE m.EmployeeID = e.ManagerID
);
Q15
select Department,(salary) 
from Employees
order by salary desc
limit 3;
